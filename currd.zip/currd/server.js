function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }

var form = document.getElementById('form');
form.addEventListener('submit', function(e){
 e.preventDefault();

    const formData=new FormData(form);
    const data = Object.fromEntries(formData);


fetch("http://localhost:2002/customorsdata",{
    method: "post",
    headers: { "Content-Type": "application/json; charset=UTF-8" 
    },
    body:JSON.stringify(data)

})
.then(res => res.json()) 
   .then(data => console.log(data))
   .catch(error => console.log(error));
});



// get

const promise = fetch("http://localhost:2002/mongotonodefulldata")

.then(function (res) {
    if (res.status === 200)
        return res.json();
        else throw new Error("Something Failed..");
        

}).then(function (data) {
    // console.log(data);
    // console.log(data[1]);
    let tableData ="";

    data.map((values)=>{
        tableData +=`<tr>
        <td>${values.name}</td>
        <td>${values.email}</td>
        <td>${values.address}</td>
        <td>${values.phoneNo}</td>
        <td>
        
        <button type="button" class="btn btn-primary edit" >
        Edit
        </button>

    
       <button class="btn btn-danger delete">Delete</button>
              
      </td>
      </tr>`;
  });
  document.getElementById("table_body").innerHTML=tableData;
})
.catch(function(err){
  console.log(err.message);
})

// ------------------------------------------------------------------------
// document.querySelector("#form").addEventListener("submit", (e) => {
//     e.preventDefault();
//     const name = document.querySelector("#name").value;
//     const email = document.querySelector("#email").value;
//     const address = document.querySelector("#address").value;
//     const phone = document.querySelector("#phoneNo").value;

//     if (name == "" || email == "" || address == "" || phoneNo == "" ) {
//         showAlert("Please fill in all fields")
//     }
//     else {
//         if (selectedRow == null) {
//             const list = document.querySelector("#table_body");
//             const row = document.createElement("tr");

//             row.innerHTML = `
//         <td>${name}</td>
//         <td>${email}</td>
//         <td>${address}</td>
//         <td>${phoneNo}</td>
//         <td>
//         <button type="button" class="btn btn-primary edit" >
//         Edit
//         </button>

    
//        <button class="btn btn-danger delete">Delete</button>
//         `;
//             list.appendChild(row);
//             selectedRow = null;
//         }
//         else {
//             selectedRow.children[0].textContent = name;
//             selectedRow.children[1].textContent = email;
//             selectedRow.children[2].textContent = address;
//             selectedRow.children[3].textContent = phoneNo;
//             selectedRow = null;
//         }
//         clearfields();
//     }

// });

// // // Edit

// document.querySelector("#table_body").addEventListener("click", (e) => {
//     target = e.target;
//     if (target.classList.contains("edit")) {
//         selectedRow = target.parentElement.parentElement;
//         document.querySelector("#name").value = selectedRow.children[0].textContent;
//         document.querySelector("#email").value = selectedRow.children[1].textContent;
//         document.querySelector("#address").value = selectedRow.children[2].textContent;
//         document.querySelector("#phoneNo").value = selectedRow.children[3].textContent;
//     }
// });


//         //     // update

            // fetch("http://localhost:2022/update/name", {
            //     method: "put",
            //     body: JSON.stringify({
            //         email:email,
            //         address:address,
            //         phoneNo:phoneNo


            //     }),
            //     headers: {
            //         "Content-Type": "application/json; charset=UTF-8"
            //     }

            // })

            //     .then(function (response) {
            //         return response.json()
            //     })
            //     .then(function (data) {
            //         console.log(data);
            //     })
            //     .catch(function (error) {
            //         console.log(error);
            //     })

            //     document.querySelector("#table_body").addEventListener("click", (e) => {
            //         e.target;
            //         if (target.classList.contains("delete")) {
            //             target.parentElement.parentElement.remove();
            //         }
            //     });
        
                        // // delete


        fetch("http://localhost:2022/del", {
            method: "delete",

            headers: {
                "Content-Type": "application/json; charset=UTF-8"
            }
        })
            .then(res => {
                if (res.ok) { console.log("HTTP request successful") }
                else { console.log("HTTP request unsuccessful") }
                return res
            })

            .then(function (response) {
                return response.json()
            })
            .then(function (data) {
                console.log(data)
            })
            .catch(function (error) {
                console.log(error)
            });
        